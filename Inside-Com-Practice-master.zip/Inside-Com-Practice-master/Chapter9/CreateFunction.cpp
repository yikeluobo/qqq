HRESULT CreateFunction(IUnknown* pUnknownOuter,
                       CUnknown** ppNewComponent);