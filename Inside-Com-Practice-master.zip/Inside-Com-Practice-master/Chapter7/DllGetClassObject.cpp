STDAPI DllGetClassObject(
    const CLSID* clsid,
    const IID& iid,
    void** ppv
);