#define CSHARP2PLUS

namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_57
{
    public class Program
    {
        public static void Main()
        {
            // ...
        }
    }
}
