namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_12
{
    public class Program
    {
        public static void Main()
        {
            int x = 0;

            x -= 2;
            x /= 2;
            x *= 2;
            x %= 2;
        }
    }
}
