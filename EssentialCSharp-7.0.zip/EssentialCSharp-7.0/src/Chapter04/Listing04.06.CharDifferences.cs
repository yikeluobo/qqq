namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_06
{
    public class Program
    {
        public static void Main()
        {
            int distance = 'f' - 'c';
            System.Console.WriteLine(distance);
        }
    }
}
