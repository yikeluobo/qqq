namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_23
{
    public class Program
    {
        public static void Main()
        {
            if(input < 9)
                System.Console.WriteLine("Exiting");
        }

        public static int input { get; set; }
    }
}
