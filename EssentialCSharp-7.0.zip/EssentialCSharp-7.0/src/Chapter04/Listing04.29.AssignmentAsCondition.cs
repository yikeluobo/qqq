namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_29
{
    public class Program
    {
        public static void Main()
        {
            // Allowed in C++, not in C#
            // if (input = 9)
            //     System.Console.WriteLine("Correct, tic-tac-toe has a maximum of 9 turns.");
        }
    }
}
