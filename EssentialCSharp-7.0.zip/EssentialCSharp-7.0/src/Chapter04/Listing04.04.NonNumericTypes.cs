namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_04
{
    public class FortyTwo
    {
        public static void Main()
        {
            short windSpeed = 42;
            System.Console.WriteLine(
                "The original Tacoma Bridge in Washington\nwas "
                + "brought down by a "
                + windSpeed + " mile/hour wind.");
        }
    }
}
