namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_59
{
    public class Program
    {
        public static void Main()
        {
#pragma warning disable 1030
        }
    }
}
