﻿namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter07.Listing07_02
{
    using Listing07_01;

    public class Program
    {
        public static void Main()
        {
            Contact contact = new Contact();
            contact.Name = "Inigo Montoya";
            // ...
        }
    }
}
