﻿namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter07.Listing07_21
{
    public class PdaItem : object
    {
        // ...
    }
}
