namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter01.Listing01_11A
{
    public class HelloWorld
    {
        public static void Main()
        {
            (string firstName, string lastName) = ("Inigo", "Montoya");
        }
    }
}
