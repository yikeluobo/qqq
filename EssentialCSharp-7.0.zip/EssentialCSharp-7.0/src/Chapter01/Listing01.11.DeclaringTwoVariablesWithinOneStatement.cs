namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter01.Listing01_11
{
    public class HelloWorld
    {
        public static void Main()
        {
            string message1, message2;

            message1 = "My name is Inigo Montoya.";;
            message2 = "You killed my father....";

            System.Console.WriteLine(message1);
            System.Console.WriteLine(message2);
        }
    }
}
