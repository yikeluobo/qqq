namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter01.Listing01_10
{
    public class MiracleMax
    {
        public static void Main()
        {
            string max;

            max = "Have fun storming the castle!";

            System.Console.WriteLine(max);
        }
    }
}
