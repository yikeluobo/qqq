namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter01.Listing01_05
{
    public class Program
    {
        public static int Main(string[] args)
        {
            // ...
            return 0;
        }
    }
}
