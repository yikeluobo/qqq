namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter01.Listing01_03
{
    public class HelloWorld
    {
        // ...
    }
}
