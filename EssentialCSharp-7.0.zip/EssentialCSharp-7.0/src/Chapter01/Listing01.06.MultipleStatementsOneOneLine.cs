namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter01.Listing01_06
{
    public class HelloWorld
    {
        public static void Main()
        {
            System.Console.WriteLine("Up");System.Console.WriteLine("Down");
        }
    }
}
