namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_28
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // ...
            string arg = args[0];
            if(arg[0] == '-')
            {
                // This parameter is an option
            }
        }
    }
}
