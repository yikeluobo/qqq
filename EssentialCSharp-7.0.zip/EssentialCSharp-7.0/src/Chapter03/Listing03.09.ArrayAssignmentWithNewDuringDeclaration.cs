namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_09
{ 
    public class Program
    { 
        public static void Main()
        {
            string[] languages = new string[] {
                "C#", "COBOL", "Java",
                "C++", "Visual Basic", "Pascal",
                "Fortran", "Lisp", "J#" };
        }
    }
}
