namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter06.Listing06_05
{
    class Employee
    {
        public string FirstName;
        public string LastName;
        public string Salary = "Not enough";
    }
}
