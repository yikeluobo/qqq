namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter06.Listing06_04
{
// In a finished implementation we would leverage our Employee object
#pragma warning disable CS0649
    class Employee
    {
        public string FirstName;
        public string LastName;
        public string Salary;
    }
#pragma warning restore CS0649
}
