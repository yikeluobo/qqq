namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter06.Listing06_43
{
    class ConvertUnits
    {
        public const float CentimetersPerInch = 2.54F;
        public const int CupsPerGallon = 16;
        // ...
    }
}
