﻿namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter09.Listing09_10
{
    enum ConnectionState
    {
        Disconnected,
        Connecting,
        Connected,
        Disconnecting
    }
}
