namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter10.Listing10_15
{
    // Define the namespace AddisonWesley
    namespace AddisonWesley
    {
        // Define the namespace AddisonWesley.Michaelis
        namespace Michaelis
        {
            // Define the namespace 
            // AddisonWesley.Michaelis.EssentialCSharp
            namespace EssentialCSharp
            {
                // Declare the class
                // AddisonWesley.Michaelis.EssentialCSharp.Program
                class Program
                {
                    // ...
                }
            }
        }
    }
    // End of AddisonWesley namespace declaration 
}
