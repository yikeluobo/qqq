﻿namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter10.Listing10_10
{
    public struct Example
    {
        //public static bool operator false(object item)
        //{
        //    return true;
        //    // ...
        //}
        //public static bool operator true(object item)
        //{
        //    return true;
        //    // ...
        //}
    }
}