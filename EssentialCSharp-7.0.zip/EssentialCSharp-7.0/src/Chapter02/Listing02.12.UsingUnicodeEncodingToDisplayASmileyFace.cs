namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_12
{
    public class SingleQuote
    {
        public static void Main()
        {
            System.Console.Write('\u003A');
            System.Console.WriteLine('\u0029');
        }
    }
}
