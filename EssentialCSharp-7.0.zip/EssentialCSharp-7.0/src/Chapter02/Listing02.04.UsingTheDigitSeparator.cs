namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_04
{
    public class Program
    {
        public static void Main()
        {
            System.Console.WriteLine(9_814_072_356M);
        }
    }
}
