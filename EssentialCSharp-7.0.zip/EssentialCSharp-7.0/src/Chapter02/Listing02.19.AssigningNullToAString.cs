namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_19
{
    public class Program
    {
        public static void Main()
        {
            string faxNumber;
            //...

            // Clear the value of faxNumber
            faxNumber = null;

            //...

            System.Console.WriteLine(faxNumber);
        }
    }
}
