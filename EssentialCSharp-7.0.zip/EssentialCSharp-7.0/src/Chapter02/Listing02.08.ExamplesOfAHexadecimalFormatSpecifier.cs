namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_08
{
    public class Program
    {
        public static void Main()
        {
            //Displays "0x2A"
            System.Console.WriteLine($"0x{42:X}");
        }
    }
}
