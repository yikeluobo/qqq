namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_06
{
    public class Program
    {
        public static void Main()
        {
            //Display the value 42 using a hexadecimal literal
            System.Console.WriteLine(0x002A);
        }
    }
}
