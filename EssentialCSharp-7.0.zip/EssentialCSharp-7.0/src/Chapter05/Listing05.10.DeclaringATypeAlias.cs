#pragma warning disable CS0168 // Variable is declared but never used
namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter05.Listing05_10
{
    using System;
    using System.Threading;
    using CountDownTimer = System.Threading.Timer;

    public class HelloWorld
    {
        public static void Main()
        {
            CountDownTimer timer;

            // ...
        }
    }
}
