namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter12.Listing12_05
{
    public delegate bool Comparer(
        int first, int second);
}
